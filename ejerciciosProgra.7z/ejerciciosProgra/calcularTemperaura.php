
<?php
class Grados {

    public $fahrenheit;
    public $centigrados;

    public function __construct($fahrenheit, $centigrados)
    {
        $this->fahrenheit=$fahrenheit;
        $this->centigrados=$centigrados;
       
    }

    public function calcular()
    {
        $fahrenheit=$this->centigrados=(9 / 5)*$this->fahrenheit+32;
        $centigrados=$this->fahrenheit;
        echo $centigrados." grados °C es equivalente a: ".$fahrenheit. " grados °F";
    }
} 
$calculo = new Grados(50, 0);

$calculo->calcular();
?>